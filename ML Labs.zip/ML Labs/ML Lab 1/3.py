# How many rows are have at least one NA / NULL value? What percentage of the dataset has missing
# values?

import pandas as pd
df = pd.read_csv('cast.csv')

print(df.isnull().any(axis=1).sum())
print(df.isnull().any(axis=1).sum() / len(df) * 100)