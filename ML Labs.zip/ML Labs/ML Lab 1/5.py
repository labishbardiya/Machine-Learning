# Display the summary statistics (max, min, mean, median etc.) for the numeric columns, and display
# top 5 most frequent columns for non-numeric columns.

import pandas as pd
df = pd.read_csv('cast.csv')

numeric_summary = df.describe()
print("Summary statistics for numeric columns:")
print(numeric_summary)

non_numeric_columns = df.select_dtypes(include=['object']).columns
for column in non_numeric_columns:
    print(f"Top 5 most frequent values for column {column}:")
    print(df[column].value_counts().head(5))