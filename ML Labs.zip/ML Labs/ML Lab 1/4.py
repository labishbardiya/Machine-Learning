# Provide a strategy to handle missing values for each column. Implement one such strategy and give a
# reason for your choice.

import pandas as pd
df = pd.read_csv('cast.csv')

df = df.fillna(0)
print(df)

# Why did I choose this strategy?

# I have used fillna() method to fill the missing values with 0. This is because the missing values are not known and it is not possible to predict the missing values. So, I have filled the missing values with 0.