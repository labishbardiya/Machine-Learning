# Display the column names and the datatypes of the columns.

import pandas as pd
df = pd.read_csv('cast.csv')

print(df.columns)
print("Datatype:", df.columns.dtype)