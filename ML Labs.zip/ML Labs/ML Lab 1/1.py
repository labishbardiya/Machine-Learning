# Import the data from the cast.csv file. Display the top 10 and bottom 10 rows and the total number of
# rows and columns.

import pandas as pd
df = pd.read_csv('cast.csv')

print(df.head(10))
print(df.tail(10))

nrows, ncols = df.shape
print("Number of Rows:", nrows)
print("Number of Columns:", ncols)