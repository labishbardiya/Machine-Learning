# Importing Data:

# 1. Import the profits data from the txt file. The first column contains the population of a city in 10,000s
# while second column contains the profit in $10,000s.

# A) show the dataframe details, rows, columns, dtypes and range of values.
# B) create a scatter plot showing the data points.

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("profits.txt", sep=",")

print(df.info())

plt.scatter(df.iloc[:, 0], df.iloc[:,1])

plt.xlabel('Population of City in 10,000s')
plt.ylabel('Profit in $10,000s')
plt.title('Scatter plot of City Population vs. Profit')

plt.show()