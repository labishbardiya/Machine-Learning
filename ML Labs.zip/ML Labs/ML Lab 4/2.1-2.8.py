# Linear Regression:

# Create a class MyLinearRegression with the following functionality:
# 1. Create a constructor, that takes the input feature matrix X and the corresponding labels vector Y. These will be compulsory arguments. Check for valid dimensions of the dataframes and display appropriate error message.
# 2. Following Instance variables to be defined; learning rate, total iterations, model parameters, etc.
# 3. Method for computing cost function ( J(Θ) ).
# 4. Method to implement “batch” gradient descent algorithm for specified number of iterations. Draw a plot showing the cost function values w.r.t. number of iterations.
# A function that will show the 3D surface plot of parameters with respect to the cost function. Choose appropriate range of values of theta and compute corresponding values.
# 6. A function that will plot the a linear model for specified values of Θ on the scatter plot shown in question 1B above.
# 7. Find the gradients after the first iteration of gradient descent when all the rows are considered in the training set and starting value of Θ = (0, 0).
# 8. Draw another 3D surface plot of parameters with respect to the cost function after feature normalization

import numpy as np
import matplotlib.pyplot as plt

class MyLinearRegression:
    def __init__(self, feature_mat, Y, learning_rate=0.01, total_iterations=1000):
        if feature_mat.ndim != 2:
            raise ValueError("feature_mat must be a 2D array")
        if Y.ndim != 1:
            raise ValueError("Y must be a 1D array")
        if feature_mat.shape[0] != Y.shape[0]:
            raise ValueError("Number of rows in feature_mat must match the length of Y")

        self.learning_rate = learning_rate
        self.total_iterations = total_iterations
        
        self.feature_mat = np.c_[np.ones((feature_mat.shape[0], 1)), feature_mat]
        self.Y = Y
        self.params = np.zeros(self.feature_mat.shape[1])
    
    def calc_cost(self):
        m = len(self.Y)
        predictions = self.feature_mat.dot(self.params)
        cost = (1/(2*m)) * np.sum((predictions - self.Y) ** 2)
        return cost
    
    def gradient_descent(self):
        m = len(self.Y)
        cost_history = []

        for i in range(self.total_iterations):
            predictions = self.feature_mat.dot(self.params)
            errors = predictions - self.Y
            
            self.params -= self.learning_rate * (1/m) * self.feature_mat.T.dot(errors)
            
            cost = self.calc_cost()
            cost_history.append(cost)
        
        return self.params, cost_history

    def plot_cost_history(self, cost_history):
        plt.plot(range(self.total_iterations), cost_history, 'b-')
        plt.xlabel('Number of iterations')
        plt.ylabel('Cost')
        plt.title('Cost function values over iterations')
        plt.show()
