# Display the average stock prices for the different years and for all the 4 stocks. Plot it on a graph for
# comparison with other companies. Create appropriate legend by keeping different stocks represented
# by different coloured lines

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('stocks.csv')

df['date'] = pd.to_datetime(df['date'])

df['year'] = df['date'].dt.year

average_prices = df.groupby('year').mean()

plt.figure(figsize=(10, 6))
for stock in ['AA', 'GE', 'IBM', 'MSFT']:
    plt.plot(average_prices.index, average_prices[stock], label=stock)

plt.title('Average Stock Prices Over Years')
plt.xlabel('Year')
plt.ylabel('Average Stock Price')
plt.legend()

plt.show()