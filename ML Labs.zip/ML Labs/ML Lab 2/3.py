# Display the summary of the dataset (using describe()). Check the data types of each column, and see if
# the dataframe is in chronological order (w.r.t. “date” column).

import pandas as pd

df = pd.read_csv('stocks.csv')

# Summary of the dataset
print(df.describe())

# Checking the data type 
print(df.dtypes)

# If the data is in chronological order
df['date'] = pd.to_datetime(df['date'])

is_chronological = df['date'].is_monotonic_increasing

print("Is data Chronological?", is_chronological)
