# How many rows have NA / NULL values.

import pandas as pd

df = pd.read_csv('stocks.csv')

print("Number of Null values:", df.isnull().any(axis=1).sum())
