# Sort the dataframe into reverse chronological order (recent first). Do not sort on the String “date”
# type. You may convert into appropriate type and save the sorted dataframe into another variable.

import pandas as pd

df = pd.read_csv('stocks.csv')

df['date'] = pd.to_datetime(df['date'])
sorted_df = df.sort_values(by='date', ascending=False)
print(sorted_df)
