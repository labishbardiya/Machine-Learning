#  Import the data from the stocks.csv file. Keep the first row and first column as column and row index
# labels, respectively. Display the top 10 and bottom 10 rows and the total number of rows and columns.

import pandas as pd
import numpy as np

df = pd.read_csv('stocks.csv')

# First Row and First Column as Column and Row index labels
df = pd.read_csv('stocks.csv', index_col=0)
df.columns = df.iloc[0]
df = df[1:]
print("First Row and First Column as Column and Row index labels:", df)

# Top 10 Rows
print("Top 10 rows: ")
print(df.head(10))

# Bottom 10 Rows
print("Bottom 10 rows: ")
print(df.tail(10))

# Number of Rows
print("Number of Rows:", len(df))

# Number of Columns
print("Number of Columns:", len(df.columns))
